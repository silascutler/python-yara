#!/usr/bin/env python

__version__ = "1.0.0"


print("[!] This is the wrong python library.  Please use yara-python")