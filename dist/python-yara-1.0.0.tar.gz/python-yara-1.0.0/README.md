# python-yara

This is not the correct yara-python module



