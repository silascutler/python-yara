#!/usr/bin/env python


print("[!] This is the wrong python library.  Please use yara-python")