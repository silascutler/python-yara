# python-yara

This is not the correct yara-python module.  Use: https://pypi.org/project/yara-python/


